var indexSectionsWithContent =
{
  0: "gkms~",
  1: "m",
  2: "gms~",
  3: "k"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "enumvalues"
};

var indexSectionLabels =
{
  0: "全部",
  1: "类",
  2: "函数",
  3: "枚举值"
};

