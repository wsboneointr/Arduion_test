# Emakefun Matrix Keyboard

这个Arduino库是用于使用`emakefun`的矩阵键盘

## 产品详情

<!-- [产品详情链接](https://emakefun-docs.readthedocs.io/zh_CN/latest/sensors/smart_modules/gesture_recognizer/) -->

## Class MatrixKeyboard 介绍

[文档链接](https://emakefun-arduino-library.github.io/emakefun_matrix_keyboard/class_matrix_keyboard.html)

## 示例程序

- 获取当前的按键值 [链接](https://emakefun-arduino-library.github.io/emakefun_matrix_keyboard/get_touched_key_8ino-example.html)
