var searchData=
[
  ['setup_0',['Setup',['../class_matrix_keyboard.html#afcd68e618a9c4bee9bfaf81bb74e91f0',1,'MatrixKeyboard']]]
];
