var searchData=
[
  ['base_0',['Base',['../class_digit_display.html#a4be0b1014611aafd077cf00d06bcd806',1,'DigitDisplay']]],
  ['blinkrate_1',['BlinkRate',['../class_digit_display.html#a471f4f5e6f960d1e1a21a30f1bdc1bfa',1,'DigitDisplay']]]
];
