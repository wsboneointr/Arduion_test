var searchData=
[
  ['kdevicei2caddressdefault_0',['kDeviceI2cAddressDefault',['../class_matrix_keyboard.html#a960af9ca272b0eaa46c8453e15231feaaee495323b23bda304a8375a898b14727',1,'MatrixKeyboard']]]
];
